package orm.core;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.List;

import jdbc.BeanHandler;
import jdbc.BeanListHandler;
import jdbc.JdbcUtils;
import jdbc.ResultSetHandler;
import orm.annotation.Table;
import orm.annotation.TableField;
import orm.annotation.Transient;

public abstract class BaseOrmSupport<T> {
	
	public void generateTable(Class class1) throws SQLException{
		Table table = (Table) class1.getAnnotation(Table.class);
		StringBuffer sql = new StringBuffer();
		sql.append("CREATE TABLE ");
		boolean mapAll = false;
		if(table != null && table.tableName().length() > 0){
			sql.append(table.tableName());
			mapAll = table.mapAll();
		}
		else{
			sql.append(class1.getSimpleName());
		}
		
		sql.append(" (");
		
		String fieldSql = "";
		//类中定义的字段
		Field[] fields = class1.getDeclaredFields();
		for(Field f : fields){
			TableField tableField = f.getAnnotation(TableField.class);
			if(tableField != null){
				if(fieldSql.length() > 0) fieldSql += ", ";
				
				fieldSql  += tableField.name();
				fieldSql += " ";
				fieldSql += tableField.sqlType();
				if(tableField.length() > 0){
					fieldSql += "("+ tableField.length()+")";
				}
				
				if(tableField.isPrimaryKey()){
					fieldSql += " primary key";
				}
				
			}
			else if(mapAll){
				Transient t = f.getAnnotation(Transient.class);
				if(t == null){
					if(fieldSql.length() > 0) fieldSql += ", ";
					fieldSql  += f.getName();
					fieldSql += " ";
					fieldSql += getSqlType(f.getType());
					if(f.getType() == String.class){
						fieldSql += "(255)";
					}
				}
			}
		}
		sql.append(fieldSql);
		sql.append(")");
		System.out.println(sql);
		
		Connection conn = JdbcUtils.getConnection();
		Statement stmt = conn.createStatement();
		int rows = stmt.executeUpdate(sql.toString());
		
		JdbcUtils.closeAll(null, stmt, conn);
	}
	
	private String getSqlType(Class<?> type) {
		if(type == String.class) return "varchar";
		if(type == int.class || type == Integer.class) return "int";
		if(type == long.class || type == Long.class) return "int";
		if(type == float.class || type == Float.class) return "float";
		if(type == double.class || type == Double.class) return "float";
		if(type == java.util.Date.class || type == java.sql.Date.class) return "datetime";
		if(type == java.sql.Timestamp.class) return "timestamp";
		
		return "varchar";
	}

	public void save(T o) throws SQLException{
		//生成sql语句
		//大致格式 insert into user (user_id,user_name,user_age)values(1,'skylun',100)
		Class class1 = o.getClass();
		Table table = (Table) class1.getAnnotation(Table.class);
		
		StringBuffer sql = new StringBuffer();
		sql.append("insert into ");
		boolean mapAll = false;
		if(table != null && table.tableName().length() > 0){
			sql.append(table.tableName());
			mapAll = table.mapAll();
		}
		else{
			sql.append(class1.getSimpleName());
		}
		
		sql.append(" (");
		
		String fieldSql = "";
		String valueSql = "";
		
		//类中定义的字段
		Field[] fields = class1.getDeclaredFields();
		for(Field f : fields){
			TableField tableField = f.getAnnotation(TableField.class);
			if(tableField != null){
				if(fieldSql.length() > 0) fieldSql += ",";
				fieldSql += tableField.name();
				
				//字段的值获得
				String fieldName = f.getName();  //name
				String getter = "get"+ fieldName.substring(0,1).toUpperCase()+
										fieldName.substring(1); //getName
				
				try {
					Method m = class1.getMethod(getter, new Class[]{});
					//调用方法
					Object value = m.invoke(o, new Object[]{});
					if(valueSql.length() > 0) valueSql += ",";
					if(value == null){
						valueSql += "null";
					}
					else{
						if(value.getClass() == String.class){
							valueSql  += "'"+value.toString()+"'";
						}
						else if(value.getClass() == java.util.Date.class
								|| value.getClass() == java.sql.Date.class || value.getClass() == java.sql.Timestamp.class){
							valueSql  += "'"+getDateString(value)+"'";
						}
						else{
							valueSql  += value.toString();
						}
					}
					
				} catch (NoSuchMethodException | SecurityException 
						| IllegalAccessException | IllegalArgumentException 
						| InvocationTargetException e) {
					e.printStackTrace();
				}
			}
			else if(mapAll){
				Transient t = f.getAnnotation(Transient.class);
				if(t == null){
					if(fieldSql.length() > 0) fieldSql += ",";
					fieldSql  += f.getName();
					
					f.setAccessible(true);
					if(valueSql.length() > 0) valueSql += ",";
					Object value;
					try {
						value = f.get(o);
						if(value == null){
							valueSql += "null";
						}
						else{
							if(value.getClass() == String.class){
								valueSql  += "'"+value.toString()+"'";
							}
							else if(value.getClass() == java.util.Date.class
									|| value.getClass() == java.sql.Date.class || value.getClass() == java.sql.Timestamp.class){
								valueSql  += "'"+getDateString(value)+"'";
							}
							else{
								valueSql  += value.toString();
							}
						}
						
					} catch (IllegalArgumentException | IllegalAccessException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				}
			}
			
		}
		
		sql.append(fieldSql);
		sql.append(") values (");
		sql.append(valueSql);
		sql.append(")");
		
		System.out.println(sql);
		
		Connection conn = JdbcUtils.getConnection();
		Statement stmt = conn.createStatement();
		int rows = stmt.executeUpdate(sql.toString());
		
		JdbcUtils.closeAll(null, stmt, conn);
	}

	private String getDateString(Object value) {
		if(value == null){
			return "null";
		}
		
		if(value.getClass() == java.util.Date.class
				|| value.getClass() == java.sql.Date.class || value.getClass() == java.sql.Timestamp.class){
			
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			return format.format(value);
		}
		
		return value.toString();
	}

	public void update(T o) throws SQLException{
		//生成sql语句
		Class class1 = o.getClass();
		Table table = (Table) class1.getAnnotation(Table.class);
		
		StringBuffer sql = new StringBuffer();
		sql.append("update ");
		boolean mapAll = false;
		if(table != null && table.tableName().length() > 0){
			sql.append(table.tableName());
			mapAll = table.mapAll();
		}
		else{
			sql.append(class1.getSimpleName());
		}
		
		sql.append(" set ");
		
		String fieldSql = "";
		String whereSql = " where ";
		
		//类中定义的字段
		Field[] fields = class1.getDeclaredFields();
		for(Field f : fields){
			TableField tableField = f.getAnnotation(TableField.class);
			if(tableField != null){
				if(tableField.isPrimaryKey()){
					whereSql += tableField.name();
					whereSql += "=";
					//字段的值获得
					String fieldName = f.getName();  //name
					String getter = "get"+ fieldName.substring(0,1).toUpperCase()+
											fieldName.substring(1); //getName
					
					try {
						Method m = class1.getMethod(getter, new Class[]{});
						//调用方法
						Object value = m.invoke(o, new Object[]{});
						if(value.getClass() == String.class){
							whereSql  += "'"+value.toString()+"'";
						}
						else{
							whereSql  += value.toString();
						}
						
					} catch (NoSuchMethodException | SecurityException 
							| IllegalAccessException | IllegalArgumentException 
							| InvocationTargetException e) {
						e.printStackTrace();
					}
				}
				else{

					if(fieldSql.length() > 0) fieldSql += ",";
					fieldSql += tableField.name();
					fieldSql += "=";
					//字段的值获得
					String fieldName = f.getName();  //name
					String getter = "get"+ fieldName.substring(0,1).toUpperCase()+
											fieldName.substring(1); //getName
					
					try {
						Method m = class1.getMethod(getter, new Class[]{});
						//调用方法
						Object value = m.invoke(o, new Object[]{});
						if(value == null){
							fieldSql += "null";
						}
						else{
							if(value.getClass() == String.class){
								fieldSql  += "'"+value.toString()+"'";
							}
							else if(value.getClass() == java.util.Date.class
									|| value.getClass() == java.sql.Date.class || value.getClass() == java.sql.Timestamp.class){
								fieldSql  += "'"+getDateString(value)+"'";
							}
							else{
								fieldSql  += value.toString();
							}
						}
						
					} catch (NoSuchMethodException | SecurityException 
							| IllegalAccessException | IllegalArgumentException 
							| InvocationTargetException e) {
						e.printStackTrace();
					}
				}
			}
			else if(mapAll){
				Transient t = f.getAnnotation(Transient.class);
				if(t == null){
					if(fieldSql.length() > 0) fieldSql += ",";

					fieldSql  += f.getName();
					fieldSql += "=";
					Object value;
					try {
						f.setAccessible(true);
						value = f.get(o);
						if(value == null){
							fieldSql += "null";
						}
						else{
							if(value.getClass() == String.class){
								fieldSql  += "'"+value.toString()+"'";
							}
							else if(value.getClass() == java.util.Date.class
									|| value.getClass() == java.sql.Date.class || value.getClass() == java.sql.Timestamp.class){
								fieldSql  += "'"+getDateString(value)+"'";
							}
							else{
								fieldSql  += value.toString();
							}
						}
					} catch (IllegalArgumentException | IllegalAccessException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}
		
		sql.append(fieldSql);
		sql.append(whereSql);
		
		System.out.println(sql);
		
		Connection conn = JdbcUtils.getConnection();
		Statement stmt = conn.createStatement();
		int rows = stmt.executeUpdate(sql.toString());
		
		JdbcUtils.closeAll(null, stmt, conn);
	}
	public void delete(T o) throws SQLException{
		//生成sql语句
		Class class1 = o.getClass();
		Table table = (Table) class1.getAnnotation(Table.class);
		
		StringBuffer sql = new StringBuffer();
		sql.append("delete from ");
		
		if(table != null && table.tableName().length() > 0){
			sql.append(table.tableName());
		}
		else{
			sql.append(class1.getSimpleName());
		}
		
		String whereSql = " where ";
		
		//类中定义的字段
		Field[] fields = class1.getDeclaredFields();
		for(Field f : fields){
			TableField tableField = f.getAnnotation(TableField.class);
			if(tableField != null){
				if(tableField.isPrimaryKey()){
					whereSql += tableField.name();
					whereSql += "=";
					//字段的值获得
					String fieldName = f.getName();  //name
					String getter = "get"+ fieldName.substring(0,1).toUpperCase()+
											fieldName.substring(1); //getName
					
					try {
						Method m = class1.getMethod(getter, new Class[]{});
						//调用方法
						Object value = m.invoke(o, new Object[]{});
						if(value.getClass() == String.class){
							whereSql  += "'"+value.toString()+"'";
						}
						else{
							whereSql  += value.toString();
						}
						
					} catch (NoSuchMethodException | SecurityException 
							| IllegalAccessException | IllegalArgumentException 
							| InvocationTargetException e) {
						e.printStackTrace();
					}
				}
				
			}
			
		}
		
		sql.append(whereSql);
		
		System.out.println(sql);
		Connection conn = JdbcUtils.getConnection();
		Statement stmt = conn.createStatement();
		int rows = stmt.executeUpdate(sql.toString());
		
		JdbcUtils.closeAll(null, stmt, conn);
	}
	public void deleteById(Class class1, Integer id) throws SQLException{
		//生成sql语句
		Table table = (Table) class1.getAnnotation(Table.class);
		
		StringBuffer sql = new StringBuffer();
		sql.append("delete  from ");
		
		if(table != null && table.tableName().length() > 0){
			sql.append(table.tableName());
		}
		else{
			sql.append(class1.getSimpleName());
		}
		
		String whereSql = " where ";
		
		//类中定义的字段
		Field[] fields = class1.getDeclaredFields();
		for(Field f : fields){
			TableField tableField = f.getAnnotation(TableField.class);
			if(tableField != null){
				if(tableField.isPrimaryKey()){
					whereSql += tableField.name();
					whereSql += "=";
					whereSql  += id.toString();
				}
			}
			
		}
		
		sql.append(whereSql);
		
		System.out.println(sql);
		
		Connection conn = JdbcUtils.getConnection();
		Statement stmt = conn.createStatement();
		int rows = stmt.executeUpdate(sql.toString());
		
		JdbcUtils.closeAll(null, stmt, conn);
		
	}
	
	public T findById(Class class1, Integer id) throws SQLException{
		//生成sql语句
		Table table = (Table) class1.getAnnotation(Table.class);
		
		StringBuffer sql = new StringBuffer();
		sql.append("select * from ");
		
		boolean mapAll = false;
		if(table != null && table.tableName().length() > 0){
			sql.append(table.tableName());
			mapAll = table.mapAll();
		}
		else{
			sql.append(class1.getSimpleName());
		}
		
		String whereSql = " where ";
		
		//类中定义的字段
		Field[] fields = class1.getDeclaredFields();
		for(Field f : fields){
			TableField tableField = f.getAnnotation(TableField.class);
			if(tableField != null){
				if(tableField.isPrimaryKey()){
					whereSql += tableField.name();
					whereSql += "=";
					whereSql  += id.toString();
				}
			}
			
		}
		
		sql.append(whereSql);
		
		System.out.println(sql);
		ResultSetHandler handler = new BeanHandler(class1,mapAll);
		Connection conn = JdbcUtils.getConnection();
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(sql.toString());
		T t = null;
		t = (T) handler.handler(rs);
		
		JdbcUtils.closeAll(null, stmt, conn);
		
		return t;
	}
	
	public List<T> findAll(Class class1) throws SQLException{
		//生成sql语句
		Table table = (Table) class1.getAnnotation(Table.class);
		
		StringBuffer sql = new StringBuffer();
		sql.append("select * from ");
		boolean mapAll = false;
		if(table != null && table.tableName().length() > 0){
			sql.append(table.tableName());
			mapAll = table.mapAll();
		}
		else{
			sql.append(class1.getSimpleName());
		}
		
		System.out.println(sql);
		
		ResultSetHandler handler = new BeanListHandler(class1, mapAll);
		Connection conn = JdbcUtils.getConnection();
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(sql.toString());
		List<T> list  = (List<T>) handler.handler(rs);
		
		JdbcUtils.closeAll(null, stmt, conn);
		
		return list;
	}

	public List<T> findByFieldValue(Class class1, String fieldName, Object fieldValue) throws SQLException{
		//生成sql语句
		Table table = (Table) class1.getAnnotation(Table.class);
		
		StringBuffer sql = new StringBuffer();
		sql.append("select * from ");
		boolean mapAll = false;
		if(table != null && table.tableName().length() > 0){
			sql.append(table.tableName());
			mapAll = table.mapAll();
		}
		else{
			sql.append(class1.getSimpleName());
		}
		
		String whereSql = " where ";
		
		//类中定义的字段
		//类中定义的字段
		Field[] fields = class1.getDeclaredFields();
		for(Field f : fields){
			TableField tableField = f.getAnnotation(TableField.class);
			if(tableField != null){
				if(fieldName.equalsIgnoreCase(f.getName())){
					whereSql += tableField.name();
					whereSql += "=";
					if(fieldValue.getClass() == String.class){
						whereSql  += "'"+fieldValue.toString()+"'";
					}
					else if(fieldValue.getClass() == java.util.Date.class
							|| fieldValue.getClass() == java.sql.Date.class || fieldValue.getClass() == java.sql.Timestamp.class){
						whereSql  += "'"+getDateString(fieldValue)+"'";
					}
					else{
						whereSql  += fieldValue.toString();
					}
				}
			}
			else if(mapAll){
				Transient t = f.getAnnotation(Transient.class);
				if(t == null){
					if(fieldName.equalsIgnoreCase(f.getName())){
						whereSql += f.getName();
						whereSql += "=";
						if(fieldValue.getClass() == String.class){
							whereSql  += "'"+fieldValue.toString()+"'";
						}
						else if(fieldValue.getClass() == java.util.Date.class
								|| fieldValue.getClass() == java.sql.Date.class || fieldValue.getClass() == java.sql.Timestamp.class){
							whereSql  += "'"+getDateString(fieldValue)+"'";
						}
						else{
							whereSql  += fieldValue.toString();
						}
					}
				}
			}
			
		}	
		if(whereSql.indexOf("=") == -1){ //没有条件
			whereSql  += "1!=1"; //
		}
		sql.append(whereSql);
		
		System.out.println(sql);
		ResultSetHandler handler = new BeanListHandler(class1, mapAll);
		Connection conn = JdbcUtils.getConnection();
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(sql.toString());
		List<T> list  = (List<T>) handler.handler(rs);
		
		JdbcUtils.closeAll(null, stmt, conn);
		
		return list;
	}
	

	public List<T> findByWhereClause(Class class1, String whereClause) throws SQLException{
		//生成sql语句
		Table table = (Table) class1.getAnnotation(Table.class);
		
		StringBuffer sql = new StringBuffer();
		sql.append("select * from ");
		boolean mapAll = false;
		if(table != null && table.tableName().length() > 0){
			sql.append(table.tableName());
			mapAll = table.mapAll();
		}
		else{
			sql.append(class1.getSimpleName());
		}
		
		String whereSql = " where 1=1 ";
		
		sql.append(whereSql);
		
		if(whereClause.length() > 0){
			sql.append(" and ");
			sql.append(whereClause);
		}
		
		System.out.println(sql);
		ResultSetHandler handler = new BeanListHandler(class1, mapAll);
		Connection conn = JdbcUtils.getConnection();
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(sql.toString());
		List<T> list  = (List<T>) handler.handler(rs);
		
		JdbcUtils.closeAll(null, stmt, conn);
		
		return list;
	}
	
}

package orm.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(value={ElementType.FIELD, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME) //注解加载到jvm中
public @interface TableField {
	public String name(); //映射的数据表字段名
	public boolean isPrimaryKey() default false; //是否是主键
	
	//sqlType
	public String sqlType() default "int";  //字段的sql类型
	//length
	public int length() default 0; //字段的长度
}

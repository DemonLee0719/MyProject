package orm.demo;

import orm.annotation.Table;
import orm.annotation.TableField;

@Table(tableName="t_user")
public class User {
	@TableField(name="user_id", isPrimaryKey=true, sqlType="int")
	private Integer id;
	@TableField(name="user_name", sqlType="varchar", length=20)
	private String name;
	@TableField(name="user_age", sqlType="int")
	private Integer age;
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", age=" + age + "]";
	}
	
	
	
}

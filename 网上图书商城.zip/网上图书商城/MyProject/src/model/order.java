package model;

import orm.annotation.Table;
import orm.annotation.TableField;

@Table(tableName="orderTable")
public class order {
	@TableField(name="oid", isPrimaryKey=true, sqlType="int")
	private Integer oid;
	
	private Integer cid;
	
	private String oaddress;
	
	private String ophone;
	
	private String opostcode;
	
	private Double money;
	
	private String sendway;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	private String payway;
	
	private String name;
	
	public order() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getOid() {
		return oid;
	}

	public void setOid(Integer oid) {
		this.oid = oid;
	}

	

	public Integer getCid() {
		return cid;
	}

	public void setCid(Integer cid) {
		this.cid = cid;
	}


	public String getOaddress() {
		return oaddress;
	}

	public void setOaddress(String oaddress) {
		this.oaddress = oaddress;
	}

	public String getOphone() {
		return ophone;
	}

	public void setOphone(String ophone) {
		this.ophone = ophone;
	}

	public String getOpostcode() {
		return opostcode;
	}

	public void setOpostcode(String opostcode) {
		this.opostcode = opostcode;
	}

	public Double getMoney() {
		return money;
	}

	public void setMoney(Double money) {
		this.money = money;
	}

	public String getSendway() {
		return sendway;
	}

	public void setSendway(String sendway) {
		this.sendway = sendway;
	}

	public String getPayway() {
		return payway;
	}

	public void setPayway(String payway) {
		this.payway = payway;
	}

	@Override
	public String toString() {
		return "order [oid=" + oid + ", cid=" + cid + ", oaddress=" + oaddress
				+ ", ophone=" + ophone + ", opostcode=" + opostcode
				+ ", money=" + money + ", sendway=" + sendway + ", payway="
				+ payway + ", name=" + name + "]";
	}

	
	
}

package model;

public class customer {
	private Integer cid;
	private String cname;
	private String cpassword;
	private String ctruename;
	private String cgender;
	private String caddr;
	

	public customer(String cname, String cpassword) {
		super();
		this.cname = cname;
		this.cpassword = cpassword;
	}
	public customer(Integer cid, String cname, String cpassword,
			String ctruename, String cgender, String caddr) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.cpassword = cpassword;
		this.ctruename = ctruename;
		this.cgender = cgender;
		this.caddr = caddr;
	}
	public customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Integer getCid() {
		return cid;
	}
	public void setCid(Integer cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getCpassword() {
		return cpassword;
	}
	public void setCpassword(String cpassword) {
		this.cpassword = cpassword;
	}
	public String getCtruename() {
		return ctruename;
	}
	public void setCtruename(String ctruename) {
		this.ctruename = ctruename;
	}
	public String getCgender() {
		return cgender;
	}
	public void setCgender(String cgender) {
		this.cgender = cgender;
	}
	public String getCaddr() {
		return caddr;
	}
	public void setCaddr(String caddr) {
		this.caddr = caddr;
	}
}

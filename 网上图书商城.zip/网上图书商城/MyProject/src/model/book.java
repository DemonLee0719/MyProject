package model;

import java.util.Date;

public class book {
	private Integer id;
	private String bname;
	private String bpress;
	private Date bpubDate;
	private String bversion;
	private String bauthor;
	private String bsize;
	private String btanslor;
	private Double bprice;
	private Integer bpages;
	private String boutline;
	private String bphoto;
	private Integer bstore;
	private Date bstoretime;
	private Integer blookmount;
	private Integer bdiscount;
	
	
	
	public book() {
		super();
		// TODO Auto-generated constructor stub
	}
	public book(Integer id, String bname, String bpress, Date bpubDate,
			String bversion, String bauthor, String bsize, String btanslor,
			Double bprice, Integer bpages, String boutline, String bphoto,
			Integer bstore, Date bstoretime, Integer blookmount,
			Integer bdiscount) {
		super();
		this.id = id;
		this.bname = bname;
		this.bpress = bpress;
		this.bpubDate = bpubDate;
		this.bversion = bversion;
		this.bauthor = bauthor;
		this.bsize = bsize;
		this.btanslor = btanslor;
		this.bprice = bprice;
		this.bpages = bpages;
		this.boutline = boutline;
		this.bphoto = bphoto;
		this.bstore = bstore;
		this.bstoretime = bstoretime;
		this.blookmount = blookmount;
		this.bdiscount = bdiscount;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public String getBpress() {
		return bpress;
	}
	public void setBpress(String bpress) {
		this.bpress = bpress;
	}
	public Date getBpubDate() {
		return bpubDate;
	}
	public void setBpubDate(Date bpubDate) {
		this.bpubDate = bpubDate;
	}
	public String getBversion() {
		return bversion;
	}
	public void setBversion(String bversion) {
		this.bversion = bversion;
	}
	public String getBauthor() {
		return bauthor;
	}
	public void setBauthor(String bauthor) {
		this.bauthor = bauthor;
	}
	public String getBsize() {
		return bsize;
	}
	public void setBsize(String bsize) {
		this.bsize = bsize;
	}
	public String getBtanslor() {
		return btanslor;
	}
	public void setBtanslor(String btanslor) {
		this.btanslor = btanslor;
	}
	public Double getBprice() {
		return bprice;
	}
	public void setBprice(Double bprice) {
		this.bprice = bprice;
	}
	public Integer getBpages() {
		return bpages;
	}
	public void setBpages(Integer bpages) {
		this.bpages = bpages;
	}
	public String getBoutline() {
		return boutline;
	}
	public void setBoutline(String boutline) {
		this.boutline = boutline;
	}
	public String getBphoto() {
		return bphoto;
	}
	public void setBphoto(String bphoto) {
		this.bphoto = bphoto;
	}
	public Integer getBstore() {
		return bstore;
	}
	public void setBstore(Integer bstore) {
		this.bstore = bstore;
	}
	public Date getBstoretime() {
		return bstoretime;
	}
	public void setBstoretime(Date bstoretime) {
		this.bstoretime = bstoretime;
	}
	public Integer getBlookmount() {
		return blookmount;
	}
	public void setBlookmount(Integer blookmount) {
		this.blookmount = blookmount;
	}
	public Integer getBdiscount() {
		return bdiscount;
	}
	public void setBdiscount(Integer bdiscount) {
		this.bdiscount = bdiscount;
	}
	
	
	
	
}

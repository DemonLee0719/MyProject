package model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import orm.annotation.Table;
import orm.annotation.TableField;
import orm.annotation.Transient;
@Table(tableName="shopcart")
public class shopcart {
	@TableField(name="sid", isPrimaryKey=true, sqlType="int")
	private Integer sid;
	@TableField(name="bid", sqlType="int")
	private Integer bid;
	@TableField(name="cid", sqlType="int")
	private Integer cid;
	@TableField(name="bnumber", sqlType="int")
	private Integer bnumber;
	@TableField(name="bprice", sqlType="double")
	private Double bprice;
	@TableField(name="ispay", sqlType="varchar")
	private String ispay;
	@TableField(name="bphoto", sqlType="varchar")
	private String bphoto;
	@TableField(name="bname", sqlType="varchar")
	private String bname;
	

	public String getBname() {
		return bname;
	}

	public void setBname(String bname) {
		this.bname = bname;
	}

	@Override
	public String toString() {
		return "shopcart [sid=" + sid + ", bid=" + bid + ", cid=" + cid
				+ ", bnumber=" + bnumber + ", bprice=" + bprice + ", ispay="
				+ ispay + ", bphoto=" + bphoto + ", bname=" + bname + "]";
	}

	public String getBphoto() {
		return bphoto;
	}

	public void setBphoto(String bphoto) {
		this.bphoto = bphoto;
	}

	public shopcart() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getSid() {
		return sid;
	}

	public void setSid(Integer sid) {
		this.sid = sid;
	}

	public Integer getBid() {
		return bid;
	}

	public void setBid(Integer bid) {
		this.bid = bid;
	}

	public Integer getCid() {
		return cid;
	}

	public void setCid(Integer cid) {
		this.cid = cid;
	}


	public Integer getBnumber() {
		return bnumber;
	}

	public void setBnumber(Integer bnumber) {
		this.bnumber = bnumber;
	}

	public Double getBprice() {
		return bprice;
	}

	public void setBprice(Double bprice) {
		this.bprice = bprice;
	}

	public String getIspay() {
		return ispay;
	}

	public void setIspay(String ispay) {
		this.ispay = ispay;
	}
	
	@Transient
	private List<book> bookList = new ArrayList<book>();
	public void addBookToCart(book book){//添加勾选书籍
		
		bookList.add(book);
		
	}
	
	public List<book> getBookList(){
		return bookList;
	}
	
	public void removeBook(int id){//移除书籍
		for(Iterator<book> i = bookList.iterator(); i.hasNext(); ){
			if(id == i.next().getId()){
				i.remove();
				break;
			}
		}
	}
	

}

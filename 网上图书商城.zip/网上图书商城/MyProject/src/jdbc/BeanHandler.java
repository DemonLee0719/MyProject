package jdbc;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

import orm.annotation.TableField;
import orm.annotation.Transient;

//框架设计者在编写这个处理器的时候，并不知道把结果集处理到哪个对象里面去，
//框架的设计者不知道没关系，但使用该框架的人总该知道，到时候在使用这个结果集处理器时传给框架设计者
public class BeanHandler implements ResultSetHandler {

  private Class clazz;
	private boolean mapAll = true;

  public BeanHandler(Class clazz, boolean mapAll) {
      this.clazz = clazz;
      this.mapAll = mapAll;
  }

  public BeanHandler(Class clazz){
	  this(clazz, true);
  }
  
  @Override
  public Object handler(ResultSet rs) {

      try {
          if (!rs.next()) {
              return null;
          }
          // 创建封装结果集的bean
          Object bean = clazz.newInstance();
	        //类中定义的字段
	  		Field[] fields = clazz.getDeclaredFields();
	  		for(Field f : fields){
	  			TableField tableField = f.getAnnotation(TableField.class);
	  			if(tableField != null){
	  			//字段的值获得
					String fieldName = f.getName();  //name
					String setter = "set"+ fieldName.substring(0,1).toUpperCase()+
											fieldName.substring(1); //getName
					 
					Object value = rs.getObject(tableField.name());    
					
					Method m = clazz.getMethod(setter, new Class[]{f.getType()});
					m.invoke(bean, value);
	  			}
	  			else if(mapAll){
	  				Transient t = f.getAnnotation(Transient.class);
					if(t == null){
		  				String fieldName = f.getName();  //name
		  				Object value = rs.getObject(fieldName);  
		  				f.setAccessible(true);
		  				f.set(bean, value);
					}
	  			}
	  		}
         
          return bean;
      } catch (Exception e) {
          throw new RuntimeException(e);
      }
  }

}
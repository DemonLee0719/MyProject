package jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;

public class IntHandler implements ResultSetHandler {

    @Override
    public Object handler(ResultSet rs) {
        try {
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return 0;
    }

}
package jdbc;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.List;

import orm.annotation.TableField;
import orm.annotation.Transient;

public class BeanListHandler implements ResultSetHandler {

    private Class clazz;
	private boolean mapAll = true;

    public BeanListHandler(Class clazz, boolean mapAll) {
        this.clazz = clazz;
        this.mapAll = mapAll;
    }
    
    public BeanListHandler(Class clazz) {
    	this(clazz, true);
    }

    @Override
    public Object handler(ResultSet rs) {
        List list = new ArrayList();
        try {
            while (rs.next()) {
                Object bean = clazz.newInstance();

              //类中定义的字段
    	  		Field[] fields = clazz.getDeclaredFields();
    	  		for(Field f : fields){
    	  			TableField tableField = f.getAnnotation(TableField.class);
    	  			if(tableField != null){
    	  			//字段的值获得
    					String fieldName = f.getName();  //name
    					String setter = "set"+ fieldName.substring(0,1).toUpperCase()+
    											fieldName.substring(1); //getName
    					 
    					Object value = rs.getObject(tableField.name());    
    					
    					Method m = clazz.getMethod(setter, new Class[]{f.getType()});
    					m.invoke(bean, value);
    	  			}
    	  			else if(mapAll){
    	  				Transient t = f.getAnnotation(Transient.class);
    					if(t == null){
    		  				String fieldName = f.getName();  //name
    		  				Object value = rs.getObject(fieldName);  
    		  				f.setAccessible(true);
    		  				f.set(bean, value);
    					}
    	  			}
    	  		}
    	  		
                list.add(bean);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return list;
    }

}
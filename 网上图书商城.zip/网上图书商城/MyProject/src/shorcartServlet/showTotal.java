package shorcartServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.shopcartDao;
import model.shopcart;

@WebServlet(urlPatterns="/showTotal")
public class showTotal extends HttpServlet {
	private shopcartDao  dao2 = new shopcartDao();
	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
		
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String sid = request.getParameter("name");
//		System.out.println(sid);
		shopcart s = null;
		List<shopcart> list = null;
		try {
			s = dao2.findById(Integer.parseInt(sid));
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		int bnumber = s.getBnumber();
		double bprice = s.getBprice();
		double total = bnumber*bprice;
		
//		System.out.println(total);
		PrintWriter pw = response.getWriter();

		pw.print(total);
		pw.flush();
		pw.close();
	}
}

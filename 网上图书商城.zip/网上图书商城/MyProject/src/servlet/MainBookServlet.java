package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import utils.Page;
import model.book;
import dao.BookDao;
import dao.BookDaoImpl;

public class MainBookServlet extends HttpServlet {
	BookDao bookDao = new BookDaoImpl();
	/**
	 * Constructor of the object.
	 */
	public MainBookServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String btid = request.getParameter("btid");
		if(btid != null){

			
			Page<book> page = null;
//			List<book> list;
			String pageNo = request.getParameter("pageNo");
			if(pageNo == null){
				pageNo = "1";	
			}
			String pageSize = request.getParameter("pageSize");
			if(pageSize == null){
				pageSize = "6";
			} 
			try {
				 page = bookDao.findByPageAndTypeId(Integer.parseInt(pageNo),Integer.parseInt(pageSize),Integer.parseInt(btid));
				 
				 
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			request.getSession().removeAttribute("btid");
			request.getSession().removeAttribute("book");
//			System.out.println(page.getList().size());
			request.removeAttribute("page");
			request.setAttribute("page", page);
			request.getSession().setAttribute("btid", btid);
			request.getRequestDispatcher("/Main.jsp")
				.forward(request, response);
			
			}
		else{
			Page<book> page = null;
//			List<book> list;
			String pageNo = request.getParameter("pageNo");
			if(pageNo == null){
				pageNo = "1";
			} 
			String pageSize = request.getParameter("pageSize");
			if(pageSize == null){
				 pageSize = "6";
			}
			try {
				 page = bookDao.findByPage(Integer.parseInt(pageNo), Integer.parseInt(pageSize));
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			request.removeAttribute("page");
			request.getSession().removeAttribute("book");
			request.setAttribute("page", page);
			
//			System.out.println(page.getList().size());
			request.getRequestDispatcher("/Main.jsp").forward(request, response);
		
		}
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}

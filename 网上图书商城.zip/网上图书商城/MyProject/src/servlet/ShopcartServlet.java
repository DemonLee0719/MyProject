package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.BookDao;
import dao.BookDaoImpl;
import dao.shopcartDao;
import dao.shopcartDao2;
import model.book;
import model.shopcart;

public class ShopcartServlet extends HttpServlet {
	private BookDao bookDao = new  BookDaoImpl();
	private shopcartDao  dao = new shopcartDao();
	private shopcartDao2  dao2 = new shopcartDao2();
	Map<String, Integer> map = new HashMap<String, Integer>();
	/**
	 * Constructor of the object.
	 */
	public ShopcartServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		HttpSession session = request.getSession();
		shopcart cart = (shopcart) session.getAttribute("cart");
		String bnumber = request.getParameter("bnumber");
//		System.out.println(bnumber);
		if(cart == null){//如果为空，。。。重新传值设置参数
			cart = new shopcart();
			session.setAttribute("bnumber", bnumber);
			session.setAttribute("cart", cart);
		}
		
		
		String id = request.getParameter("id");
		System.out.println("id="+id);
		String action = request.getParameter("action");
		System.out.println(action);
		Object cid =  request.getSession().getAttribute("cid");
		System.out.println(cid);
		String sid = request.getParameter("sid");
		System.out.println("sid="+sid);
		shopcart s = new shopcart();
		List<shopcart> list = null;
		
		if(sid!=null && "remove".equals(action)){
			System.out.println("删除这条记录购物车");
			try {
				dao2.deleteById(cart.getClass(), Integer.parseInt(sid));
			} catch (NumberFormatException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
		
		
		try {
			list = dao2.findByFieldValue(s.getClass(), "cid", Integer.parseInt(String.valueOf(cid)));
			session.setAttribute("list", list);
		} catch (NumberFormatException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		} catch (SQLException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		
//		System.out.println(cid);
		if(id!=null){
			if("remove".equals(action)){
//				System.out.println("删除");
				cart.removeBook(Integer.parseInt(sid));//将String型的id转型为int
				
			}
			else{
				book b = new book();
				
				try {
					b = bookDao.findById(Integer.parseInt(id));
					
				} catch (NumberFormatException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				if(b!=null){
					
					cart.addBookToCart(b);
					
					int bid = b.getId();
					Double bprice = b.getBprice();
					String bphoto = b.getBphoto();
					String bname = b.getBname();
					
					try {
						dao.addToShopcart(Integer.parseInt(String.valueOf(cid)),
								bid,Integer.parseInt(bnumber), bprice,bphoto,bname,"否");
						list = dao2.findByFieldValue(s.getClass(), "cid", Integer.parseInt(String.valueOf(cid)));
						session.setAttribute("list", list);
					} catch (NumberFormatException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
						Integer times = (Integer) session.getAttribute("add");
					   	if(times==null){
					   		times = 1;
					   		map.put(id, times);
					   	}
					   	times++;
					   	session.setAttribute("add",map.get(id));
					
				}
			}
		}
//		response.sendRedirect("/shopcart.jsp");
		request.getRequestDispatcher("/shopcart.jsp").forward(request, response);
		
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}

package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;
import model.book;
import dao.BookDao;
import dao.BookDaoImpl;

public class BookChangeServlet extends HttpServlet {
	BookDao bookDao = new BookDaoImpl();
	/**
	 * Constructor of the object.
	 */
	public BookChangeServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
		
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("application/json;charset=utf-8");
		String id = request.getParameter("id");
//		System.out.println(id);
		String bname = request.getParameter("bname");
		String bpress = request.getParameter("bpress");
		String bpubDate = request.getParameter("bpubDate");
		String bversion = request.getParameter("bversion");
		String bauthor = request.getParameter("bauthor");
		String bsize = request.getParameter("bsize");
		String btanslor = request.getParameter("btanslor");
		String bprice = request.getParameter("bprice");
		String bpages = request.getParameter("bpages");
		String boutline = request.getParameter("boutline");
		String bphoto = request.getParameter("bphoto");
		String bstore = request.getParameter("bstore");
		String bstoretime = request.getParameter("bstoretime");
		String blookmount = request.getParameter("blookmount");
		String bdiscount = request.getParameter("bdiscount");
		SimpleDateFormat sd = new SimpleDateFormat("yyyy-MM-dd");
		Date bpd = null;
		Date bst = null;
		try {
			bpd = sd.parse(bpubDate);
			bst = sd.parse(bstoretime);
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		book book = new book();
		book.setId(Integer.parseInt(id));
		book.setBpress(bpress);
		book.setBname(bname);
		book.setBpubDate(bpd);
		book.setBauthor(bauthor);
		book.setBversion(bversion);
		book.setBsize(bsize);
		book.setBtanslor(btanslor);
		book.setBprice(Double.parseDouble(bprice));
		book.setBpages(Integer.parseInt(bpages));
		book.setBoutline(boutline);
		book.setBphoto(bphoto);
		book.setBstore(Integer.parseInt(bstore));
		book.setBstoretime(bst);
		book.setBlookmount(Integer.parseInt(blookmount));
		book.setBdiscount(Integer.parseInt(bdiscount));
		JSONObject json = new JSONObject();
		try {
			bookDao.changeBook(book);
			json.put("success", true);
			json.put("message", "员工信息更新成功");
		} catch (SQLException e) {
			e.printStackTrace();
			json.put("success", false);
			json.put("message", "员工信息更新失败，出错信息:" + e.getMessage());
		}
		
		
		PrintWriter pw = response.getWriter();
		pw.write(json.toString());
		pw.flush();
		pw.close();

		
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}

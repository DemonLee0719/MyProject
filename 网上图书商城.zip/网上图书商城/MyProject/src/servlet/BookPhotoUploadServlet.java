package servlet;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collection;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet(urlPatterns="/BookPhotoUploadServlet",
	initParams={@WebInitParam(name="path", value="/images")})
@MultipartConfig //处理文件上传
public class BookPhotoUploadServlet extends HttpServlet {
	private String path = "/images";
	/**
	 * Constructor of the object.
	 */
	public BookPhotoUploadServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		ServletContext sc = request.getServletContext();
		request.setCharacterEncoding("utf-8");
		
		String filename = "";
		//获取上传的文件集合
		Collection<Part>  parts = request.getParts();
		for(Part part : parts){
			String header = part.getHeader("content-disposition");
			//System.out.println("header="+header);
			String fieldName = part.getName();
			
			if(header.indexOf("filename=") != -1){ //处理文件字段
				filename = header.substring(
						header.indexOf("filename=")
							+"filename=".length());
				
				filename = filename.substring(1, filename.length()-1);
				//System.out.println("filename=" + filename);
				//拷贝文件
				part.write(sc.getRealPath(path)
							+ File.separator + filename);
				request.getSession().setAttribute("bphoto", filename);
				break; //上传处理了一张图片
			}
		}
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}

package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.BookDao;
import dao.BookDaoImpl;
import model.book;
import utils.Page;

public class BookSerachServlet extends HttpServlet {
	BookDao bookDao = new BookDaoImpl();
	/**
	 * Constructor of the object.
	 */
	public BookSerachServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String serach = request.getParameter("serach");
		

		Page<book> page = null;
//		List<book> list;
		String pageNo = request.getParameter("pageNo");
		if(pageNo == null){
			pageNo = "1";
		} 
		String pageSize = request.getParameter("pageSize");
		if(pageSize == null){
			 pageSize = "6";
		}
		try {
			 page = bookDao.findBookByCond(Integer.parseInt(pageNo), Integer.parseInt(pageSize),serach);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		request.removeAttribute("page");
		request.getSession().removeAttribute("book");
		request.setAttribute("page", page);
//		System.out.println(page.getList().size());
		request.getRequestDispatcher("/Main.jsp").forward(request, response);
		
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}

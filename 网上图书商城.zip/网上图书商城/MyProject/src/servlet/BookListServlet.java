package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;
import net.sf.json.JSONSerializer;
import net.sf.json.JsonConfig;
import net.sf.json.processors.JsonValueProcessor;
import model.book;
import utils.Page;
import dao.BookDao;
import dao.BookDaoImpl;

public class BookListServlet extends HttpServlet {
	BookDao bookDao = new BookDaoImpl();
	/**
	 * Constructor of the object.
	 */
	public BookListServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("utf-8");
		response.setContentType("application/json;charset=utf-8");
		 JsonConfig jf = new JsonConfig();  
        //jf.registerJsonValueProcessor(java.sql.Timestamp.class, new DateJsonValueProcessor("yyyy-MM-dd HH:mm:ss"));  
        jf.registerJsonValueProcessor(java.sql.Timestamp.class, new DateJsonValueProcessor("yyyy-MM-dd"));  
        jf.registerJsonValueProcessor(java.util.Date.class, new DateJsonValueProcessor("yyyy-MM-dd"));  
        Map<String, Object> map  = new HashMap<String, Object>();
        String pageNo = request.getParameter("page");
        String bname = request.getParameter("bname");
       
//        System.out.println(pageNo);
		if(pageNo == null){pageNo = "1";} 
		String pageSize = request.getParameter("rows");
		if(pageSize == null){pageSize = "10";} 
//     JSONArray jsonArray  = new JSONArray();
		
		if(bname!=null){
			try {
				Page<book> page = bookDao.findBookByCond(Integer.parseInt(pageNo), Integer.parseInt(pageSize), bname);
				map.put("total", page.getAll());
				map.put("rows", page.getList());
				JSONObject json = (JSONObject) JSONSerializer.toJSON(map, jf);
				PrintWriter out = response.getWriter();
				out.print(json.toString());
//				System.out.println(json.toString());
				out.flush();out.close();
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else{
			try {
				Page<book> page = bookDao.findByPage(Integer.parseInt(pageNo), Integer.parseInt(pageSize));
				map.put("total", page.getAll());
				map.put("rows", page.getList());
				JSONObject json = (JSONObject) JSONSerializer.toJSON(map, jf);
				PrintWriter out = response.getWriter();
				out.print(json.toString());
//				System.out.println(json.toString());
				out.flush();out.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		
		
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}
	
	class DateJsonValueProcessor implements JsonValueProcessor  
	{  
	      
	    private String format;  
	    public DateJsonValueProcessor(String format){  
	        this.format = format;  
	    }  
	      
	    public Object processArrayValue(Object value, JsonConfig jsonConfig)  
	    {  
	        return null;  
	    }  
	  
	    public Object processObjectValue(String key, Object value, JsonConfig jsonConfig)  
	    {  
	        if(value == null)  
	        {  
	            return "";  
	        }  
	        if(value instanceof java.sql.Timestamp)  
	        {  
	            String str = new SimpleDateFormat(format).format((java.sql.Timestamp)value);  
	            return str;  
	        }  
	        if (value instanceof java.util.Date)  
	        {  
	            String str = new SimpleDateFormat(format).format((java.util.Date) value);  
	            return str;  
	        }  
	          
	        return value.toString();  
	    }  
	}

}

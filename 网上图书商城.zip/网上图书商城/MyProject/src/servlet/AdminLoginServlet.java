package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.MyProjectAdminDao;
import dao.MyProjectAdminDaoImpl;
@WebServlet(urlPatterns="/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {
	MyProjectAdminDao adminDao = new MyProjectAdminDaoImpl();
	/**
	 * Constructor of the object.
	 */
	public AdminLoginServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String name = request.getParameter("adminName");
		String password = request.getParameter("adminPassword");
		int flag = 0;
		try {
			flag = adminDao.queryAflagByAdminNameAndPasswrd(name, password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(flag == 1){
			request.getSession().setAttribute("admin", name);
			request.getRequestDispatcher("/background/BKmain.jsp").forward(request, response);
			
		}
		else if(flag == 2){
			request.getRequestDispatcher("/background/Admin2.jsp").forward(request, response);
		}
		else if(flag == 3){
			request.getRequestDispatcher("/background/Admin3.jsp").forward(request, response);
		}
		else{
			PrintWriter out = response.getWriter();
			out.print("该管理员无权限");
			out.flush();out.close();
		}
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}

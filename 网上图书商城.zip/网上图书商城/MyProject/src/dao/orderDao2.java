package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import utils.JdbcUtils;

public class orderDao2 {
	public void save(Integer cid,String oaddress,String ophone,String opostcode,Double money,String sendway,String payway,String name) throws SQLException {
		Connection conn = JdbcUtils.getConnection();
		String sql = "insert into orderTable (cid,oaddress,ophone,opostcode,money,sendway,payway,name) values (?,?,?,?,?,?,?,?)";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, cid);
		pstmt.setString(2, oaddress);
		pstmt.setString(3, ophone);
		pstmt.setString(4, opostcode);
		pstmt.setDouble(5, money);
		pstmt.setString(6, sendway);
		pstmt.setString(7, payway);
		pstmt.setString(8, name);
		pstmt.executeUpdate();
		JdbcUtils.closeAll(null, pstmt, conn);
		
	}
	
}

package dao;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import utils.Page;
import model.book;

public interface BookDao {
	List<book> queryAllBook ()  throws SQLException;
	Page<book> findByPage(int pageNo, int pageSize) throws SQLException;
	Page<book> findByPageAndTypeId( int pageNo, int pageSize , int btid) throws SQLException;
	public int countAll() throws SQLException ;
	public int count(int bid) throws SQLException ;
	public int count(String serach) throws SQLException ;
	void deleteBookById(Integer id) throws SQLException ;
	void addBook(book b) throws SQLException ;
	void changeBook(book b) throws SQLException ;
	book findById(Integer id) throws SQLException ;
	Page<book> findBookByCond(int parseInt, int parseInt2, String serach) throws SQLException ;
} 

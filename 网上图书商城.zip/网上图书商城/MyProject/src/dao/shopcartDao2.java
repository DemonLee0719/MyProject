package dao;

import model.shopcart;
import orm.core.BaseOrmSupport;

public class shopcartDao2 extends BaseOrmSupport<shopcart> {

}

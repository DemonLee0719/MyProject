package dao;

import java.sql.SQLException;
import java.util.List;

import model.customer;

public interface MyProjectDao  {
	void insertToMyProByCon(String name,String phone,
					String email,String password) throws SQLException;
	
	List<customer> queryAllByNameAndPassword(String name,String password) 
			throws SQLException;
	customer queryCustomerByNameAndPassword(String name,String password) 
			throws SQLException;
}

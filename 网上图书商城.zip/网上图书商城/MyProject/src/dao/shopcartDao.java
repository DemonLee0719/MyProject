package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.shopcart;
import utils.JdbcUtils;

public class shopcartDao {
	public void addToShopcart(Integer cid,Integer bid,Integer bnumber,Double bprice,String bphoto,String bname,String ispay) throws SQLException{
		Connection conn = JdbcUtils.getConnection();
		String sql = "insert into shopcart (cid,bid,bnumber,bprice,bphoto,bname,ispay) values (?,?,?,?,?,?,?)";
				
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, cid);
		pstmt.setInt(2, bid);
		pstmt.setInt(3, bnumber);
		pstmt.setDouble(4, bprice);
		pstmt.setString(5, bphoto);
		pstmt.setString(6, bname);
		pstmt.setString(7, ispay);
		pstmt.executeUpdate();
		JdbcUtils.closeAll(null, pstmt, conn);
	}
	
	public shopcart findById(Integer sid) throws SQLException{
		Connection conn = JdbcUtils.getConnection();
		String sql = "select * from shopcart where sid = ?";
				
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, sid);
		shopcart s = null;
		ResultSet rs = pstmt.executeQuery();
		if(rs.next()){
			s = new shopcart();
			s.setSid(sid);
			s.setCid(rs.getInt(2));
			s.setBid(rs.getInt(3));
			s.setBnumber(rs.getInt(4));
			s.setBprice(rs.getDouble(5));
			s.setBphoto(rs.getString(6));
			s.setBname(rs.getString(7));
			s.setIspay(rs.getString(8));
	
		}
		
		JdbcUtils.closeAll(null, pstmt, conn);
		return s;
	}
	
}

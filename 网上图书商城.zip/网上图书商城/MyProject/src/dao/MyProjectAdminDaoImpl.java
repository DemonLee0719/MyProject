package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import utils.JdbcUtils;

public class MyProjectAdminDaoImpl implements MyProjectAdminDao {

	@Override
	public int queryAflagByAdminNameAndPasswrd(String adminName,
			String adminPassword) throws SQLException {
		Connection conn = JdbcUtils.getConnection();
		String sql = "select aflag from admin where aname = ? && apassword = ?";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, adminName);
		pstmt.setString(2, adminPassword);
		ResultSet rs = pstmt.executeQuery();
		int result = 0;
		if(rs.next()){
			result = rs.getInt(1);
		}
		JdbcUtils.closeAll(rs, pstmt, conn);
		return result;
	}

}

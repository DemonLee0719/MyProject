package dao;

import model.order;
import orm.core.BaseOrmSupport;

public class orderDao extends BaseOrmSupport<order> {

}

package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.customer;
import utils.JdbcUtils;

public class MyProjectDaoImpl implements MyProjectDao {

	@Override
	public void insertToMyProByCon(String name, String phone, String email,
			String password) throws SQLException {
		// TODO Auto-generated method stub
		Connection conn = JdbcUtils.getConnection();
		String sql = "insert into customer (cname,cphone,cemail,cpassword) values (?,?,?,?)";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, name);
		pstmt.setString(2, phone);
		pstmt.setString(3, email);
		pstmt.setString(4, password);
		int row = pstmt.executeUpdate();
		JdbcUtils.closeAll(null, pstmt, conn);
	}

	@Override
	public List<customer> queryAllByNameAndPassword(String name, String password)
			throws SQLException {
		//建立连接
		Connection conn = JdbcUtils.getConnection();
		//创建sql语句
		String sql = "select * from customer where cname = ? and cpassword= ? ";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, name);
		pstmt.setString(2, password);
		ResultSet rs = pstmt.executeQuery();
		List<customer> list = new ArrayList<customer>();
		while(rs.next()){
			customer cu = new customer();
			cu.setCid(rs.getInt(1));
			cu.setCname(rs.getString(2));
			cu.setCpassword(rs.getString(3));
			cu.setCtruename(rs.getString(4));
			cu.setCgender(rs.getString(5));
			cu.setCaddr(rs.getString(6));
			list.add(cu);
		}
		JdbcUtils.closeAll(null, pstmt, conn);
		return list;
	}

	@Override
	public customer queryCustomerByNameAndPassword(String name, String password)
			throws SQLException {
		//建立连接
		Connection conn = JdbcUtils.getConnection();
		//创建sql语句
		String sql = "select * from customer where cname = ? and cpassword= ? ";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, name);
		pstmt.setString(2, password);
		ResultSet rs = pstmt.executeQuery();
		customer cu = null;
		if(rs.next()){
			cu = new customer();
			cu.setCid(rs.getInt(1));
			cu.setCname(rs.getString(2));
			cu.setCpassword(rs.getString(3));
			cu.setCtruename(rs.getString(4));
			cu.setCgender(rs.getString(5));
			cu.setCaddr(rs.getString(6));
		}
		JdbcUtils.closeAll(rs, pstmt, conn);
		return cu;
	}


}

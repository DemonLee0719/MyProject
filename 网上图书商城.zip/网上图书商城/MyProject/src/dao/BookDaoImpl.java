package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import utils.JdbcUtils;
import utils.Page;
import model.book;

public class BookDaoImpl implements BookDao {

	@Override
	public List<book> queryAllBook() throws SQLException {
		Connection conn = JdbcUtils.getConnection();
		String sql = "select *from book";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		List<book> list = new ArrayList<book>();
		while(rs.next()){
			book book = new book();
			book.setId(rs.getInt(1));
			book.setBname(rs.getString(2));
			book.setBpress(rs.getString(3));
			book.setBpubDate(rs.getDate(4));
			book.setBversion(rs.getString(5));
			book.setBauthor(rs.getString(6));
			book.setBsize(rs.getString(7));
			book.setBtanslor(rs.getString(8));
			book.setBprice(rs.getDouble(9));
			book.setBpages(rs.getInt(10));
			book.setBoutline(rs.getString(11));
			book.setBphoto(rs.getString(12));
			book.setBstore(rs.getInt(13));
			book.setBstoretime(rs.getDate(14));
			book.setBlookmount(rs.getInt(15));
			book.setBdiscount(rs.getInt(16));
			list.add(book);
		}
		JdbcUtils.closeAll(rs, pstmt, conn);
		return list;
	}

	@Override
	public Page<book> findByPage(int pageNo, int pageSize) throws SQLException {
		int all = this.countAll();
		Page<book> page = new Page<book>(all, pageSize, pageNo);
		List<book> list = new ArrayList<book>();
		
		Connection conn = JdbcUtils.getConnection();
		String sql = "select * from book limit ?, ?";//Sql分页语句，第一个参数为起始下标，第二个参数为大小
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, page.getStartIndex());
		pstmt.setInt(2, pageSize);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()){
			book book = new book();
			book.setId(rs.getInt(1));
			book.setBname(rs.getString(2));
			book.setBpress(rs.getString(3));
			book.setBpubDate(rs.getDate(4));
			book.setBversion(rs.getString(5));
			book.setBauthor(rs.getString(6));
			book.setBsize(rs.getString(7));
			book.setBtanslor(rs.getString(8));
			book.setBprice(rs.getDouble(9));
			book.setBpages(rs.getInt(10));
			book.setBoutline(rs.getString(11));
			book.setBphoto(rs.getString(12));
			book.setBstore(rs.getInt(13));
			book.setBstoretime(rs.getDate(14));
			book.setBlookmount(rs.getInt(15));
			book.setBdiscount(rs.getInt(16));
			list.add(book);
		}
		JdbcUtils.closeAll(rs, pstmt, conn);
		page.setList(list);
		return page;
	}

	@Override
	public Page<book> findByPageAndTypeId(int pageNo, int pageSize, int btid)
			throws SQLException {
		int count = this.count(btid);
		Page<book> page = new Page<book>(count, pageSize, pageNo);
		List<book> list = new ArrayList<book>();
		
		Connection conn = JdbcUtils.getConnection();
		String sql = "select b.* from book b,booktype bp,"
				+ "bookAndBooktypeRe bar where "
				+ "b.bid = bar.bid and bar.btid=bp.btid and bp.btid = ?  limit ?, ?";//Sql分页语句，第一个参数为起始下标，第二个参数为大小
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, btid);
		pstmt.setInt(2, page.getStartIndex());
		pstmt.setInt(3, pageSize);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()){
			book book = new book();
			book.setId(rs.getInt(1));
			book.setBname(rs.getString(2));
			book.setBpress(rs.getString(3));
			book.setBpubDate(rs.getDate(4));
			book.setBversion(rs.getString(5));
			book.setBauthor(rs.getString(6));
			book.setBsize(rs.getString(7));
			book.setBtanslor(rs.getString(8));
			book.setBprice(rs.getDouble(9));
			book.setBpages(rs.getInt(10));
			book.setBoutline(rs.getString(11));
			book.setBphoto(rs.getString(12));
			book.setBstore(rs.getInt(13));
			book.setBstoretime(rs.getDate(14));
			book.setBlookmount(rs.getInt(15));
			book.setBdiscount(rs.getInt(16));
			list.add(book);
		}
		
		JdbcUtils.closeAll(rs, pstmt, conn);
		page.setList(list);
		return page;
	}
	
	
	@Override
	public int countAll() throws SQLException {
		Connection conn = JdbcUtils.getConnection();
		Statement stmt = conn.createStatement();
		String sql = "select count(*) from book";
		ResultSet rs = stmt.executeQuery(sql);
		int all = 0;
		if(rs.next()){
			all = rs.getInt(1);
		}
		JdbcUtils.closeAll(rs, stmt, conn);
		return all;
	}

	@Override
	public void deleteBookById(Integer id) throws SQLException {
		Connection conn = JdbcUtils.getConnection();
		String sql = "delete from book where bid=?";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.executeUpdate();
		JdbcUtils.closeAll(null, pstmt, conn);
	}

	@Override
	public void addBook(book b) throws SQLException {
		Connection conn = JdbcUtils.getConnection();
		String sql = "insert into book "
				+ "( bid,  bname,  bpress,bpubDate,  bversion,"
				+ "  bauthor,  bsize,btanslor,  bprice,  bpages,  "
				+ "boutline, bphoto,  bstore,  bstoretime,  blookmount,"
				+ "bdiscount) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, b.getId());
		pstmt.setString(2, b.getBname());
		pstmt.setString(3, b.getBpress());
		pstmt.setDate(4, new java.sql.Date(b.getBpubDate().getTime()));
		pstmt.setString(5, b.getBversion());
		pstmt.setString(6, b.getBauthor());
		pstmt.setString(7, b.getBsize());
		pstmt.setString(8, b.getBtanslor());
		pstmt.setDouble(9, b.getBprice());
		pstmt.setInt(10, b.getBpages());
		pstmt.setString(11, b.getBoutline());
		pstmt.setString(12, b.getBphoto());
		pstmt.setInt(13, b.getBstore());
		pstmt.setDate(14, new java.sql.Date(b.getBstoretime().getTime()));
		pstmt.setInt(15, b.getBlookmount());
		pstmt.setInt(16, b.getBdiscount());
		pstmt.executeUpdate();
		JdbcUtils.closeAll(null, pstmt, conn);
	}

	@Override
	public void changeBook(book b) throws SQLException {
		// TODO Auto-generated method stub
		Connection conn = JdbcUtils.getConnection();
		String sql = "update book set "
				+ " bname=?,  bpress=?,bpubDate=?,  bversion=?,"
				+ "  bauthor=?,  bsize=?,btanslor=?,  bprice=?,  bpages=?,  "
				+ "boutline=?, bphoto=?,  bstore=?,  bstoretime=?,  blookmount=?,"
				+ "bdiscount=? where bid=? ";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, b.getBname());
		pstmt.setString(2, b.getBpress());
		pstmt.setDate(3, new java.sql.Date(b.getBpubDate().getTime()));
		pstmt.setString(4, b.getBversion());
		pstmt.setString(5, b.getBauthor());
		pstmt.setString(6, b.getBsize());
		pstmt.setString(7, b.getBtanslor());
		pstmt.setDouble(8, b.getBprice());
		pstmt.setInt(9, b.getBpages());
		pstmt.setString(10, b.getBoutline());
		pstmt.setString(11, b.getBphoto());
		pstmt.setInt(12, b.getBstore());
		pstmt.setDate(13, new java.sql.Date(b.getBstoretime().getTime()));
		pstmt.setInt(14, b.getBlookmount());
		pstmt.setInt(15, b.getBdiscount());
		pstmt.setInt(16, b.getId());
		pstmt.executeUpdate();
		JdbcUtils.closeAll(null, pstmt, conn);
	}

	@Override
	public book findById(Integer id) throws SQLException {
		Connection conn = JdbcUtils.getConnection();
		String sql = "select * from book where bid=?";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, id);
		ResultSet rs = pstmt.executeQuery();
		book book = new book();
		if(rs.next()){
			book.setId(rs.getInt(1));
			book.setBname(rs.getString(2));
			book.setBpress(rs.getString(3));
			book.setBpubDate(rs.getDate(4));
			book.setBversion(rs.getString(5));
			book.setBauthor(rs.getString(6));
			book.setBsize(rs.getString(7));
			book.setBtanslor(rs.getString(8));
			book.setBprice(rs.getDouble(9));
			book.setBpages(rs.getInt(10));
			book.setBoutline(rs.getString(11));
			book.setBphoto(rs.getString(12));
			book.setBstore(rs.getInt(13));
			book.setBstoretime(rs.getDate(14));
			book.setBlookmount(rs.getInt(15));
			book.setBdiscount(rs.getInt(16));
		}
		JdbcUtils.closeAll(rs, pstmt, conn);
		return book;
	}

	@Override
	public int count(int bid) throws SQLException {
		Connection conn = JdbcUtils.getConnection();
		
		String sql = "select count(*) from book b,booktype bp,"
				+ "bookAndBooktypeRe bar where "
				+ "b.bid = bar.bid and bar.btid=bp.btid and bp.btid = ?";//Sql分页语句，第一个参数为起始下标，第二个参数为大小
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, bid);
		ResultSet rs = pstmt.executeQuery();
		int all = 0;
		if(rs.next()){
			all = rs.getInt(1);
		}
		JdbcUtils.closeAll(rs, pstmt, conn);
		return all;
	}

	@Override
	public Page<book> findBookByCond(int pageNo, int pageSize, String serach) throws SQLException {
		int count = this.count(serach);
		Page<book> page = new Page<book>(count, pageSize, pageNo);
		List<book> list = new ArrayList<book>();
		
		Connection conn = JdbcUtils.getConnection();
		String sql = "select * from book where bname like ? ";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, "%"+serach+"%");
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()){
			book book = new book();
			book.setId(rs.getInt(1));
			book.setBname(rs.getString(2));
			book.setBpress(rs.getString(3));
			book.setBpubDate(rs.getDate(4));
			book.setBversion(rs.getString(5));
			book.setBauthor(rs.getString(6));
			book.setBsize(rs.getString(7));
			book.setBtanslor(rs.getString(8));
			book.setBprice(rs.getDouble(9));
			book.setBpages(rs.getInt(10));
			book.setBoutline(rs.getString(11));
			book.setBphoto(rs.getString(12));
			book.setBstore(rs.getInt(13));
			book.setBstoretime(rs.getDate(14));
			book.setBlookmount(rs.getInt(15));
			book.setBdiscount(rs.getInt(16));
			list.add(book);
		}
		
		JdbcUtils.closeAll(rs, pstmt, conn);
		page.setList(list);
		
		return page;
	}

	@Override
	public int count(String serach) throws SQLException {
		Connection conn = JdbcUtils.getConnection();
		String sql = "select count(*) from book where bname like ? ";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, "%"+serach+"%");
//		System.out.println(sql);
		
		ResultSet rs = pstmt.executeQuery();
		int all = 0;
		if(rs.next()){
			all = rs.getInt(1);
		}
		JdbcUtils.closeAll(rs, pstmt, conn);
		return all;
	}

	

	

}

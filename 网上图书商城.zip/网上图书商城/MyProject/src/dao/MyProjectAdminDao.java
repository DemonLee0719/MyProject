package dao;

import java.sql.SQLException;

public interface MyProjectAdminDao {
	int queryAflagByAdminNameAndPasswrd(String adminName,String adminPassword)
				throws SQLException;
}

package orderServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.orderDao;
import dao.orderDao2;
import model.order;
@WebServlet(urlPatterns="/orderSaveServlet2")
public class orderSaveServlet extends HttpServlet {
	orderDao2 dao = new orderDao2();
	/**
	 * Constructor of the object.
	 */
	public orderSaveServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		Object cid = request.getSession().getAttribute("cid");
		System.out.println(cid);
		String name = request.getParameter("name");
		String oaddress = request.getParameter("address");
		System.out.println(oaddress);
		String ophone = request.getParameter("phone");
		String opostcode = request.getParameter("postcode");
		String money = request.getParameter("money");
		
		String money1 = (String) request.getSession().getAttribute("money1");
		System.out.println(money);
		System.out.println(money1);
		String sendway = "快递包邮";
		String payway = "在线支付";
		if(ophone==null){
			request.getSession().setAttribute("money1", money);
			request.getRequestDispatcher("/order.jsp").forward(request, response);
		}
		else{
//			order o = new order();
////			o.setOid(100);
//			o.setCid(Integer.parseInt(String.valueOf(cid)));
//			o.setOaddress(oaddress);
//			o.setOphone("15116365944");
//			o.setOpostcode(opostcode);
//			o.setMoney(15.6);
//			o.setSendway(sendway);
//			o.setPayway(payway);
//			System.out.println(o.toString());
			try {
//				dao.save(o);
//				System.out.println(oaddress);
				dao.save(Integer.parseInt(String.valueOf(cid)),
						oaddress, ophone, opostcode,
						Double.parseDouble(money1),
						sendway, payway,name);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			request.getRequestDispatcher("/MainBookServlet").forward(request, response);
		}
		
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}

package utils;

import java.util.List;

public class Page<T> {
	private int all;//总记录数
	private int pageSize;//页大小
	private int currPage;//当前页
	//前一页
	private int prevPage;
	//后一页
	private int nextPage;
	
	//总页数
	private int totalPage;
	//起始下标
	private int startIndex;
	//结束下标
	private int endIndex;
	//当前页记录
	private List<T> list;
	
	
	public List<T> getList() {
		return list;
	}
	public void setList(List<T> list) {
		this.list = list;
	}
	public int getAll() {
		return all;
	}
	public int getPageSize() {
		return pageSize;
	}
	public int getCurrPage() {
		return currPage;
	}
	public int getPrevPage() {
		return prevPage;
	}
	public int getNextPage() {
		return nextPage;
	}
	public int getTotalPage() {
		return totalPage;
	}
	public int getStartIndex() {
		return startIndex;
	}
	public int getEndIndex() {
		return endIndex;
	}
	public Page(int all, int pageSize, int currPage) {
		super();
		this.all = all;
		this.pageSize = pageSize;
		this.currPage = currPage;
		
		totalPage = (all+(pageSize-1))/pageSize; //计算总页数
		//规范当前页
		if(currPage <=1){
			currPage = 1;
		}
		if(currPage > totalPage){
			currPage = totalPage;
		}
		prevPage = currPage== 1?1:currPage-1;
		nextPage = currPage==totalPage?totalPage:currPage+1;
		startIndex = pageSize*(currPage-1);
		endIndex = pageSize*currPage;
	}
	
	
}
